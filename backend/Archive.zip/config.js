const JWT_SECRET = "prasad.hp-TextGram"

export default JWT_SECRET